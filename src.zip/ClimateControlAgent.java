import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;

public class ClimateControlAgent extends Agent {
    private String plantType;

    protected void setup() {
        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            plantType = (String) args[0];
        }

        if (SystemConfig.DISPLAY_TERMINAL_OUTPUT) {
            System.out.println("ClimateControlAgent for " + plantType + " started.");
        }

        addBehaviour(new TickerBehaviour(this, SystemConfig.BEHAVIOR_INTERVAL) {
            protected void onTick() {
                try {
                    if (SystemConfig.DISPLAY_TERMINAL_OUTPUT) {
                        switch (plantType) {
                            case "Tomatoes":
                                System.out.println("  - Climate Settings for Tomatoes:");
                                System.out.println("    - Humidity: " + SystemConfig.TOMATOES_HUMIDITY + "%");
                                System.out.println("    - Temperature: " + SystemConfig.TOMATOES_TEMPERATURE + "°C");
                                break;
                            case "Cucumbers":
                                System.out.println("  - Climate Settings for Cucumbers:");
                                System.out.println("    - Humidity: " + SystemConfig.CUCUMBERS_HUMIDITY + "%");
                                System.out.println("    - Temperature: " + SystemConfig.CUCUMBERS_TEMPERATURE + "°C");
                                break;
                            case "Lettuce":
                                System.out.println("  - Climate Settings for Lettuce:");
                                System.out.println("    - Humidity: " + SystemConfig.LETTUCE_HUMIDITY + "%");
                                System.out.println("    - Temperature: " + SystemConfig.LETTUCE_TEMPERATURE + "°C");
                                break;
                            case "Herbs":
                                System.out.println("  - Climate Settings for Herbs:");
                                System.out.println("    - Humidity: " + SystemConfig.HERBS_HUMIDITY + "%");
                                System.out.println("    - Temperature: " + SystemConfig.HERBS_TEMPERATURE + "°C");
                                break;
                            default:
                                System.out.println("  - Monitoring climate for unspecified plants...");
                                break;
                        }
                    }
                    Thread.sleep(SystemConfig.CLIMATE_ADJUSTMENT_DELAY);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
