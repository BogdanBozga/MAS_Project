import jade.core.Runtime;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.StaleProxyException;

public class MainController {
    public static void main(String[] args) {
        Runtime rt = Runtime.instance();
        Profile p = new ProfileImpl();
        AgentContainer mainContainer = rt.createMainContainer(p);

        try {
            String[] agentNames = {"ClimateControlAgent", "GrowthMonitoringAgent", "HarvestingAgent",
                                   "IrrigationAgent", "LightingControlAgent", "LogisticsAndDistributionAgent",
                                   "NutrientManagementAgent"};
            String[] plantTypes = {"Tomatoes", "Cucumbers", "Lettuce", "Herbs"};
            for (String plant : plantTypes) {
                for (String agentName : agentNames) {
                    AgentController ac = mainContainer.createNewAgent(agentName + plant, agentName, new Object[]{plant});
                    ac.start();
                }
            }
        } catch (StaleProxyException e) {
            e.printStackTrace();
        }
    }
}